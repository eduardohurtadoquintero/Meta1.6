// ============================================================
// article-manager.js — Article CRUD + rendering
// ============================================================

import { showToast }           from './error-handler.js';
import { setLoading, setEmpty, setContent } from './loading-indicator.js';
import { openModal }           from './app.js';
import { RUBRIC, renderRubricForm, computeScore } from './app.js';

export async function loadArticles(containerId, apiCall, user) {
  setLoading(containerId, true);
  try {
    const articles = await apiCall('/articles');
    if (!articles.length) {
      setEmpty(containerId, '📭', 'No hay artículos aquí', 'Los artículos aparecerán aquí cuando estén disponibles.');
      return;
    }
    renderArticleList(containerId, articles, user, apiCall);
  } catch (err) {
    setContent(containerId, `<div class="alert alert-error">Error cargando artículos: ${err.message}</div>`);
  }
}

function renderArticleList(containerId, articles, user, apiCall) {
  const el = document.getElementById(containerId);
  if (!el) return;

  el.innerHTML = articles.map(a => articleHTML(a, user)).join('');

  // Bind buttons
  el.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', () => {
      const { action, id, title } = btn.dataset;
      if (action === 'assign')      handleAssign(id, apiCall, () => loadArticles(containerId, apiCall, user));
      if (action === 'view-reviews') handleViewReviews(id, user, apiCall);
      if (action === 'review')       handleReview(id, title, apiCall, () => loadArticles(containerId, apiCall, user), user);
      if (action === 'my-review')    handleMyReview(id, user, apiCall);
    });
  });
}

function articleHTML(a, user) {
  const status = { received:'📨 Recibido', in_review:'📝 En revisión', reviewed:'✅ Revisado' }[a.status] || a.status;
  const badgeCls = `badge-${a.status}`;
  const date = new Date(a.createdAt).toLocaleDateString('es-ES', { day:'2-digit', month:'short', year:'numeric' });

  let actions = '';
  if (user.role === 'editor') {
    if (a.status === 'received')  actions += `<button class="btn btn-primary btn-sm" data-action="assign" data-id="${a.id}">👥 Asignar revisores</button>`;
    if (a.status !== 'received')  actions += `<button class="btn btn-secondary btn-sm" data-action="view-reviews" data-id="${a.id}">💬 Ver revisiones</button>`;
  }
  if (user.role === 'author' && a.status === 'reviewed') {
    actions += `<button class="btn btn-secondary btn-sm" data-action="view-reviews" data-id="${a.id}">💬 Ver revisiones</button>`;
  }
  if (user.role === 'reviewer') {
    const myDone = a._myReview;
    if (!myDone) actions += `<button class="btn btn-primary btn-sm" data-action="review" data-id="${a.id}" data-title="${escHtml(a.title)}">✍️ Revisar</button>`;
    else         actions += `<button class="btn btn-secondary btn-sm" data-action="my-review" data-id="${a.id}">👁 Mi revisión</button>`;
  }

  return `
    <div class="article-item">
      <div class="article-item-title">${escHtml(a.title)}</div>
      <div class="article-item-meta">
        ${user.role !== 'author' ? `<span>👤 ${escHtml(a.authorName || a.authorId)}</span>` : ''}
        <span>📂 ${escHtml(a.area)}</span>
        <span>🗓 ${date}</span>
      </div>
      <div class="article-item-footer">
        <div class="btn-group">${actions}</div>
        <span class="badge ${badgeCls}">${status}</span>
      </div>
    </div>`;
}

// ── Assign reviewers ──────────────────────────────────────────

async function handleAssign(articleId, apiCall, reload) {
  let reviewers;
  try { reviewers = await apiCall('/users/reviewers'); } catch (e) { showToast('Error: ' + e.message, 'error'); return; }

  const body = `
    <p style="color:var(--text-3);font-size:.85rem;margin-bottom:1.25rem">Selecciona entre 2 y 3 revisores para este artículo.</p>
    <form id="assignForm">
      ${reviewers.map(r => `
        <label style="display:flex;align-items:center;gap:.75rem;padding:.65rem;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius-sm);margin-bottom:.5rem;cursor:pointer">
          <input type="checkbox" name="rev" value="${r.id}" style="width:auto;accent-color:var(--accent)">
          <span>
            <span style="font-weight:500;color:var(--text-1)">${escHtml(r.name)}</span>
            <span style="font-size:.75rem;color:var(--text-3);display:block">${r.email}</span>
          </span>
        </label>`).join('')}
      <div class="btn-group" style="margin-top:1.25rem">
        <button type="submit" class="btn btn-primary">✅ Asignar</button>
        <button type="button" class="btn btn-secondary" onclick="window._closeModal()">Cancelar</button>
      </div>
    </form>`;

  openModal('Asignar revisores', body);

  document.getElementById('assignForm').addEventListener('submit', async e => {
    e.preventDefault();
    const selected = [...document.querySelectorAll('input[name="rev"]:checked')].map(cb => cb.value);
    if (selected.length < 2 || selected.length > 3) { showToast('Selecciona 2 o 3 revisores', 'error'); return; }
    try {
      await apiCall(`/articles/${articleId}/assign`, { method:'PUT', body: JSON.stringify({ reviewerIds: selected }) });
      showToast('✅ Revisores asignados', 'success');
      window._closeModal();
      reload();
    } catch (err) { showToast('Error: ' + err.message, 'error'); }
  });
}

// ── View reviews ──────────────────────────────────────────────

async function handleViewReviews(articleId, user, apiCall) {
  let reviews;
  try { reviews = await apiCall(`/reviews/${articleId}`); } catch (e) { showToast('Error: ' + e.message, 'error'); return; }

  if (!reviews.length) { showToast('Sin revisiones aún', 'info'); return; }

  const body = reviews.map((r, i) => {
    const score = computeScore(r.scores);
    return `
      <div class="review-card">
        <div class="review-card-header">
          <div>
            <div class="review-card-name">Revisor ${i + 1}${user.role === 'editor' ? ` — ${escHtml(r.reviewerName)}` : ''}</div>
            <div class="review-card-date">${new Date(r.submittedAt).toLocaleString('es-ES')}</div>
          </div>
          <div class="score-display" style="padding:.6rem 1.25rem;margin:0">
            <div class="score-value" style="font-size:1.6rem">${score}</div>
            <div class="score-label">/ 5.00</div>
          </div>
        </div>
        <div class="score-grid">
          ${RUBRIC.criteria.map(c => `
            <div class="score-cell">
              <div class="score-cell-label">${c.name}</div>
              <div class="score-cell-value">${r.scores?.[c.id] ?? '—'}<span style="font-size:.7rem;color:var(--text-3)">/5</span></div>
            </div>`).join('')}
        </div>
        <div class="comment-block">
          <div class="comment-block-title">💬 Comentarios para el autor</div>
          <p style="font-size:.875rem;color:var(--text-2);line-height:1.65">${escHtml(r.comments)}</p>
        </div>
        ${user.role === 'editor' && r.editorComment ? `
        <div class="comment-block confidential">
          <div class="comment-block-title">🔒 Comentarios confidenciales (editor)</div>
          <p style="font-size:.875rem;color:var(--text-2);line-height:1.65">${escHtml(r.editorComment)}</p>
        </div>` : ''}
      </div>`;
  }).join('');

  openModal(`Revisiones (${reviews.length})`, body);
}

// ── Perform review ────────────────────────────────────────────

async function handleReview(articleId, articleTitle, apiCall, reload, user) {
  const body = `
    <p style="color:var(--text-3);font-size:.85rem;margin-bottom:1.5rem">
      Evaluando: <strong style="color:var(--text-1)">${articleTitle}</strong>
    </p>
    <form id="reviewForm">
      ${renderRubricForm()}

      <div class="score-display hidden" id="liveScore">
        <div class="score-value" id="liveScoreVal">—</div>
        <div class="score-label">Calificación ponderada / 5.00</div>
      </div>

      <div class="form-group" style="margin-top:1.25rem">
        <label>💬 Comentarios para el autor <span style="color:var(--red)">*</span></label>
        <textarea id="rc_authorComments" required minlength="100" rows="5"
          placeholder="Proporciona retroalimentación constructiva (mínimo 100 caracteres)…"></textarea>
        <span style="font-size:.72rem;color:var(--text-3)" id="charCount">0 / mín. 100</span>
      </div>

      <div class="form-group">
        <label>🔒 Comentarios confidenciales para el editor <span style="font-size:.75rem;color:var(--text-3)">(opcional — solo el editor los verá)</span></label>
        <textarea id="rc_editorComment" rows="3"
          placeholder="Recomendación de aceptación/rechazo, notas internas…"></textarea>
      </div>

      <div class="btn-group" style="margin-top:1.25rem">
        <button type="submit" class="btn btn-success">📨 Enviar revisión</button>
        <button type="button" class="btn btn-secondary" onclick="window._closeModal()">Cancelar</button>
      </div>
    </form>`;

  openModal('Revisar artículo', body);

  // Live score update
  document.querySelectorAll('.rating-opt').forEach(inp => {
    inp.addEventListener('change', updateLiveScore);
  });

  // Char counter
  document.getElementById('rc_authorComments').addEventListener('input', function() {
    const n = this.value.length;
    const el = document.getElementById('charCount');
    el.textContent = `${n} / mín. 100`;
    el.style.color = n >= 100 ? 'var(--green)' : 'var(--text-3)';
  });

  document.getElementById('reviewForm').addEventListener('submit', async e => {
    e.preventDefault();
    const scores = {};
    let allFilled = true;
    RUBRIC.criteria.forEach(c => {
      const sel = document.querySelector(`.rating-opt[name="${c.id}"]:checked`);
      if (sel) scores[c.id] = parseInt(sel.value);
      else allFilled = false;
    });
    if (!allFilled) { showToast('Evalúa todos los criterios', 'error'); return; }

    const comments      = document.getElementById('rc_authorComments').value;
    const editorComment = document.getElementById('rc_editorComment').value;

    try {
      await apiCall('/reviews', {
        method: 'POST',
        body: JSON.stringify({ articleId, scores, comments, editorComment: editorComment || null })
      });
      showToast('✅ Revisión enviada', 'success');
      window._closeModal();
      reload();
    } catch (err) { showToast('Error: ' + err.message, 'error'); }
  });
}

function updateLiveScore() {
  const scores = {};
  let all = true;
  RUBRIC.criteria.forEach(c => {
    const sel = document.querySelector(`.rating-opt[name="${c.id}"]:checked`);
    if (sel) scores[c.id] = parseInt(sel.value); else all = false;
  });
  const el = document.getElementById('liveScore');
  if (!el) return;
  if (all) {
    el.classList.remove('hidden');
    document.getElementById('liveScoreVal').textContent = computeScore(scores);
  } else {
    el.classList.add('hidden');
  }
}

// ── My review ─────────────────────────────────────────────────

async function handleMyReview(articleId, user, apiCall) {
  let reviews;
  try { reviews = await apiCall(`/reviews/${articleId}`); } catch (e) { showToast('Error: ' + e.message, 'error'); return; }
  const mine = reviews.find(r => r.reviewerId === user.id);
  if (!mine) { showToast('No se encontró tu revisión', 'error'); return; }

  const score = computeScore(mine.scores);
  const body = `
    <div class="score-display">
      <div class="score-value">${score}</div>
      <div class="score-label">Tu calificación ponderada / 5.00</div>
    </div>
    <div class="score-grid" style="margin-bottom:1.25rem">
      ${RUBRIC.criteria.map(c => `
        <div class="score-cell">
          <div class="score-cell-label">${c.name}</div>
          <div class="score-cell-value">${mine.scores?.[c.id] ?? '—'}<span style="font-size:.7rem;color:var(--text-3)">/5</span></div>
        </div>`).join('')}
    </div>
    <div class="comment-block">
      <div class="comment-block-title">💬 Tus comentarios para el autor</div>
      <p style="font-size:.875rem;color:var(--text-2);line-height:1.65">${escHtml(mine.comments)}</p>
    </div>
    ${mine.editorComment ? `
    <div class="comment-block confidential">
      <div class="comment-block-title">🔒 Tus comentarios confidenciales</div>
      <p style="font-size:.875rem;color:var(--text-2);line-height:1.65">${escHtml(mine.editorComment)}</p>
    </div>` : ''}
    <p style="font-size:.75rem;color:var(--text-3);margin-top:1rem">
      Enviado: ${new Date(mine.submittedAt).toLocaleString('es-ES')}
    </p>`;

  openModal('Tu revisión', body);
}

// ── Util ──────────────────────────────────────────────────────
function escHtml(str = '') {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}
