// ============================================================
// sync-manager.js — Offline queue & sync status
// ============================================================

import { showToast } from './error-handler.js';

const SYNC_DB   = 'peerreview-sync';
const SYNC_VER  = 1;
const QUEUE_KEY = 'syncQueue';

let _db = null;

async function openDb() {
  if (_db) return _db;
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(SYNC_DB, SYNC_VER);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(QUEUE_KEY))
        db.createObjectStore(QUEUE_KEY, { keyPath: 'id', autoIncrement: true });
    };
    req.onsuccess = e => { _db = e.target.result; resolve(_db); };
    req.onerror   = ()  => reject(req.error);
  });
}

export async function enqueue(item) {
  const db    = await openDb();
  const entry = { ...item, ts: Date.now(), retries: 0 };
  return new Promise((resolve, reject) => {
    const tx = db.transaction(QUEUE_KEY, 'readwrite');
    const req = tx.objectStore(QUEUE_KEY).add(entry);
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

export async function dequeue(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(QUEUE_KEY, 'readwrite');
    const req = tx.objectStore(QUEUE_KEY).delete(id);
    req.onsuccess = () => resolve();
    req.onerror   = () => reject(req.error);
  });
}

export async function listQueue() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(QUEUE_KEY, 'readonly');
    const req = tx.objectStore(QUEUE_KEY).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

// ── Status ───────────────────────────────────────────────────

let statusEl = null;
let dotEl    = null;

export function initSyncUI(statusId, dotId) {
  statusEl = document.getElementById(statusId);
  dotEl    = document.getElementById(dotId);
  updateStatus();
  window.addEventListener('online',  () => { updateStatus(); flushQueue(); });
  window.addEventListener('offline', () => updateStatus());
}

function updateStatus() {
  if (!dotEl || !statusEl) return;
  if (!navigator.onLine) {
    dotEl.className   = 'sync-dot offline';
    statusEl.textContent = 'offline';
  } else {
    dotEl.className   = 'sync-dot';
    statusEl.textContent = 'online';
  }
}

export function setSyncing(yes) {
  if (!dotEl) return;
  dotEl.className = yes ? 'sync-dot syncing' : 'sync-dot';
}

// ── Flush queue when back online ──────────────────────────────

let _apiCall = null;

export function registerApiCall(fn) { _apiCall = fn; }

export async function flushQueue() {
  if (!navigator.onLine || !_apiCall) return;
  const items = await listQueue();
  if (!items.length) return;

  setSyncing(true);
  let flushed = 0;
  for (const item of items) {
    try {
      await _apiCall(item.endpoint, item.options);
      await dequeue(item.id);
      flushed++;
    } catch {
      // Leave in queue for next attempt
    }
  }
  setSyncing(false);
  if (flushed) showToast(`${flushed} operación(es) sincronizadas`, 'success');
}
