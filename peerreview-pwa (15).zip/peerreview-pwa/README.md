# 📄 PeerReview PWA v6.0

Sistema completo de revisión por pares — PWA con estructura modular.

## 📁 Estructura

```
peerreview-pwa/
├── backend/
│   ├── server.js          # Express + auth + CRUD completo
│   └── package.json
├── js/
│   ├── app.js             # Lógica principal + routing por rol
│   ├── article-manager.js # CRUD artículos + UI
│   ├── sync-manager.js    # Sincronización offline / IndexedDB queue
│   ├── error-handler.js   # Toasts + mensajes de error
│   └── loading-indicator.js
├── css/
│   ├── main.css           # Variables, reset, tipografía
│   └── components.css     # Cards, forms, badges, modal, rubric
├── index.html
├── db.js                  # IndexedDB wrapper
├── manifest.json          # PWA config
└── sw.js                  # Service Worker (cache-first)
```

## 🚀 Inicio rápido

### 1. Backend
```bash
cd backend
npm install
npm start
# → http://localhost:3001
```

### 2. Frontend (sirve la raíz del proyecto)
```bash
# desde la raíz peerreview-pwa/
python3 -m http.server 8000 --bind 0.0.0.0
# → http://localhost:8000
```

## 👤 Usuarios de demo

| Email | Contraseña | Rol |
|-------|-----------|-----|
| autor@test.com | autor123 | Autor |
| editor@test.com | editor123 | Editor |
| revisor@test.com | revisor123 | Revisor |
| revisor2@test.com | revisor123 | Revisor |

También puedes **registrar tu propia cuenta** desde la pestaña "Crear cuenta" (roles autor / revisor).

## 🎯 Flujo completo

1. **Autor** → Inicia sesión → Envía artículo
2. **Editor** → Inicia sesión → Asigna 2-3 revisores al artículo
3. **Revisor** → Inicia sesión → Ve artículos asignados → Realiza revisión con rúbrica:
   - 4 criterios: Originalidad (25%), Metodología (30%), Resultados (25%), Redacción (20%)
   - Escala 1-5 con calificación ponderada en tiempo real
   - Comentarios para el autor (mínimo 100 chars)
   - Comentarios confidenciales para el editor (opcionales)
4. **Autor** → Ve revisiones (sin ver comentarios confidenciales)
5. **Editor** → Ve TODO: calificaciones + comentarios públicos + confidenciales

## 🔐 Sistema de cuentas

- Cada usuario tiene email único + contraseña propia
- Registro de nuevas cuentas (autor / revisor)
- Sesiones con token Bearer (24h)
- Roles: author, editor, reviewer
- Los editores solo pueden ser creados en el backend (por seguridad)

## 📱 PWA Features

- Service Worker con cache-first para assets
- Network-first para llamadas API
- Sync queue en IndexedDB para operaciones offline
- Indicador de estado online/offline en el header
- Instalable en Android/iOS
