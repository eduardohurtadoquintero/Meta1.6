import { db } from '../db.js';
import { ArticleManager } from './article-manager.js';
import { CommentSystem } from './comment-system.js';
import { ErrorHandler } from './error-handler.js';
import { LoadingIndicator } from './loading-indicator.js';

// Estado global
let currentUser = {
  id: 'user-author-1',
  role: 'author',
  name: 'Miguel Torres'
};

let currentFilter = 'all';
let currentArticleForAssignment = null;

// Inicialización
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🚀 Iniciando aplicación...');
  
  // Registrar Service Worker
  registerServiceWorker();
  
  // Verificar estado del sistema
  await checkSystemStatus();
  
  // Configurar event listeners
  setupEventListeners();
  
  // Mostrar secciones según rol
  updateUIByRole();
  
  // Cargar datos iniciales
  await loadDataByRole();
  
  // Detectar cambios online/offline
  setupNetworkDetection();
  
  console.log('✅ Aplicación iniciada');
});

// ============================================
// MANEJO DE ROLES Y PERMISOS
// ============================================

function updateUIByRole() {
  const role = currentUser.role;
  
  // Mostrar/ocultar secciones según rol
  document.querySelectorAll('[data-role]').forEach(section => {
    const sectionRole = section.getAttribute('data-role');
    section.style.display = sectionRole === role ? 'block' : 'none';
  });
  
  // Actualizar display de rol actual
  const roleDisplay = document.getElementById('currentRoleDisplay');
  if (roleDisplay) {
    const roleLabels = {
      author: '🎓 Autor',
      editor: '👨‍💼 Editor',
      reviewer: '👩‍🔬 Revisor'
    };
    roleDisplay.textContent = roleLabels[role];
  }
}

async function loadDataByRole() {
  const role = currentUser.role;
  
  try {
    if (role === 'author') {
      await loadAuthorArticles();
    } else if (role === 'editor') {
      await loadEditorArticles();
    } else if (role === 'reviewer') {
      await loadReviewerArticles();
    }
  } catch (error) {
    ErrorHandler.error('Error cargando datos: ' + error.message);
  }
}

// ============================================
// AUTOR: Subir y Ver Mis Artículos
// ============================================

async function loadAuthorArticles() {
  const container = document.getElementById('authorArticlesList');
  
  try {
    LoadingIndicator.show('Cargando tus artículos...');
    
    const articles = await ArticleManager.getArticlesByAuthor(currentUser.id);
    
    if (articles.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>📭 No has enviado artículos aún.</p>
          <p class="empty-state-hint">Usa el formulario de arriba para enviar tu primer artículo.</p>
        </div>
      `;
      return;
    }
    
    container.innerHTML = articles.map(article => {
      const statusBadge = getStatusBadge(article.status);
      const hasReviews = article.status === 'reviewed';
      
      return `
        <div class="article-card">
          <div class="article-header">
            <div class="article-title">
              <strong>${escapeHtml(article.title)}</strong>
              ${statusBadge}
            </div>
            <div class="article-actions">
              <button class="btn-icon" onclick="window.downloadArticlePDF('${article.id}')" title="Descargar PDF">
                📥
              </button>
              ${hasReviews ? `
                <button class="btn-icon" onclick="window.viewArticleComments('${article.id}', 'author')" title="Ver Comentarios">
                  💬
                </button>
              ` : ''}
            </div>
          </div>
          
          <div class="article-meta">
            <span>📂 ${escapeHtml(article.area)}</span>
            <span>📄 ${escapeHtml(article.fileName)} (${ArticleManager.formatFileSize(article.fileSize)})</span>
            <span>🕐 ${new Date(article.createdAt).toLocaleDateString('es-ES')}</span>
          </div>
          
          ${article.abstract ? `
            <div class="article-abstract">
              <strong>Resumen:</strong> ${escapeHtml(article.abstract)}
            </div>
          ` : ''}
          
          ${article.assignedReviewers.length > 0 ? `
            <div class="article-reviewers">
              <strong>Estado:</strong> ${article.assignedReviewers.length} revisores asignados
            </div>
          ` : `
            <div class="article-status-pending">
              ⏳ Pendiente de asignación de revisores
            </div>
          `}
        </div>
      `;
    }).join('');
    
  } catch (error) {
    ErrorHandler.error('Error cargando artículos: ' + error.message);
  } finally {
    LoadingIndicator.hide();
  }
}

// ============================================
// EDITOR: Ver Todos los Artículos y Asignar
// ============================================

async function loadEditorArticles() {
  const container = document.getElementById('editorArticlesList');
  
  try {
    LoadingIndicator.show('Cargando artículos...');
    
    const articles = await ArticleManager.getArticlesByStatus(currentFilter);
    const counts = await ArticleManager.countByStatus();
    
    // Actualizar contadores
    document.getElementById('countAll').textContent = counts.all;
    document.getElementById('countReceived').textContent = counts.received;
    document.getElementById('countInReview').textContent = counts.in_review;
    document.getElementById('countReviewed').textContent = counts.reviewed;
    
    if (articles.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>📭 No hay artículos con este estado.</p>
        </div>
      `;
      return;
    }
    
    container.innerHTML = articles.map(article => {
      const statusBadge = getStatusBadge(article.status);
      const canAssign = article.status === 'received' || article.status === 'in_review';
      const hasReviews = article.status === 'reviewed';
      
      return `
        <div class="article-card">
          <div class="article-header">
            <div class="article-title">
              <strong>${escapeHtml(article.title)}</strong>
              ${statusBadge}
            </div>
            <div class="article-actions">
              <button class="btn-icon" onclick="window.downloadArticlePDF('${article.id}')" title="Descargar PDF">
                📥
              </button>
              ${canAssign ? `
                <button class="btn-icon" onclick="window.openAssignReviewers('${article.id}')" title="Asignar Revisores">
                  👥
                </button>
              ` : ''}
              ${hasReviews ? `
                <button class="btn-icon" onclick="window.viewArticleComments('${article.id}', 'editor')" title="Ver Comentarios">
                  💬
                </button>
              ` : ''}
            </div>
          </div>
          
          <div class="article-meta">
            <span>📂 ${escapeHtml(article.area)}</span>
            <span>👤 Autor: ${escapeHtml(article.authorId)}</span>
            <span>📄 ${escapeHtml(article.fileName)}</span>
            <span>🕐 ${new Date(article.createdAt).toLocaleDateString('es-ES')}</span>
          </div>
          
          ${article.assignedReviewers.length > 0 ? `
            <div class="article-reviewers">
              <strong>Revisores asignados:</strong> ${article.assignedReviewers.length}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');
    
  } catch (error) {
    ErrorHandler.error('Error cargando artículos: ' + error.message);
  } finally {
    LoadingIndicator.hide();
  }
}

// ============================================
// REVISOR: Ver Artículos Asignados
// ============================================

async function loadReviewerArticles() {
  const container = document.getElementById('reviewerArticlesList');
  
  // Obtener ID del revisor actual (simulación)
  const reviewerId = 'reviewer-1'; // En producción esto vendría de la sesión
  
  try {
    LoadingIndicator.show('Cargando artículos asignados...');
    
    const articles = await ArticleManager.getArticlesByReviewer(reviewerId);
    
    if (articles.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>📭 No tienes artículos asignados aún.</p>
          <p class="empty-state-hint">El editor te asignará artículos para revisar.</p>
        </div>
      `;
      return;
    }
    
    // Verificar estado de revisión de cada artículo
    const articlesWithReviewStatus = await Promise.all(
      articles.map(async (article) => {
        const review = await db.reviews
          .where({ articleId: article.id, reviewerId: reviewerId })
          .first();
        return { ...article, reviewStatus: review?.status || 'pending' };
      })
    );
    
    container.innerHTML = articlesWithReviewStatus.map(article => {
      const statusBadge = getStatusBadge(article.status);
      const reviewStatusBadge = getReviewStatusBadge(article.reviewStatus);
      
      return `
        <div class="article-card">
          <div class="article-header">
            <div class="article-title">
              <strong>${escapeHtml(article.title)}</strong>
              ${statusBadge}
              ${reviewStatusBadge}
            </div>
            <div class="article-actions">
              <button class="btn-icon" onclick="window.downloadArticlePDF('${article.id}')" title="Descargar PDF">
                📥
              </button>
              ${article.reviewStatus !== 'submitted' ? `
                <button class="btn-icon btn-primary" onclick="window.openReviewForm('${article.id}')" title="Revisar">
                  ✍️
                </button>
              ` : `
                <button class="btn-icon" onclick="window.viewMyReview('${article.id}')" title="Ver mi revisión">
                  👁️
                </button>
              `}
            </div>
          </div>
          
          <div class="article-meta">
            <span>📂 ${escapeHtml(article.area)}</span>
            <span>📄 ${escapeHtml(article.fileName)}</span>
            <span>🕐 Asignado: ${new Date(article.updatedAt).toLocaleDateString('es-ES')}</span>
          </div>
          
          ${article.abstract ? `
            <div class="article-abstract">
              <strong>Resumen:</strong> ${escapeHtml(article.abstract)}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');
    
  } catch (error) {
    ErrorHandler.error('Error cargando artículos: ' + error.message);
  } finally {
    LoadingIndicator.hide();
  }
}

// ============================================
// EVENT LISTENERS
// ============================================

function setupEventListeners() {
  // Form de autor: subir artículo
  const authorForm = document.getElementById('authorUploadForm');
  if (authorForm) {
    authorForm.addEventListener('submit', handleAuthorSubmit);
  }
  
  // Selector de rol
  const roleSelect = document.getElementById('roleSelect');
  if (roleSelect) {
    roleSelect.addEventListener('change', handleRoleChange);
  }
  
  // Filtros de editor
  const filterTabs = document.querySelectorAll('.filter-tab');
  filterTabs.forEach(tab => {
    tab.addEventListener('click', handleFilterChange);
  });
  
  // Botón asignar revisores
  const confirmAssignBtn = document.getElementById('confirmAssignReviewers');
  if (confirmAssignBtn) {
    confirmAssignBtn.addEventListener('click', handleConfirmAssignment);
  }
  
  // Form de revisión
  const reviewForm = document.getElementById('reviewForm');
  if (reviewForm) {
    reviewForm.addEventListener('submit', handleReviewSubmit);
  }
  
  // Botón guardar borrador
  const saveDraftBtn = document.getElementById('saveDraftBtn');
  if (saveDraftBtn) {
    saveDraftBtn.addEventListener('click', () => handleSaveReview('draft'));
  }
  
  // Sincronizar sliders con outputs
  ['Originality', 'Methodology', 'Results', 'Writing'].forEach(criterion => {
    const slider = document.getElementById(`score${criterion}`);
    const output = document.getElementById(`output${criterion}`);
    if (slider && output) {
      slider.addEventListener('input', () => {
        output.textContent = slider.value;
      });
    }
  });
  
  // Contador de caracteres en comentarios
  const commentsTextarea = document.getElementById('reviewComments');
  if (commentsTextarea) {
    commentsTextarea.addEventListener('input', updateCharCount);
  }
}

// Handler: Submit formulario de autor
async function handleAuthorSubmit(e) {
  e.preventDefault();
  
  const formData = new FormData(e.target);
  
  try {
    const article = await ArticleManager.createArticle({
      title: formData.get('title'),
      area: formData.get('area'),
      pdfFile: formData.get('pdfFile'),
      abstract: formData.get('abstract'),
      authorId: currentUser.id
    });
    
    ErrorHandler.success(`Artículo "${article.title}" enviado exitosamente`);
    e.target.reset();
    await loadAuthorArticles();
    
  } catch (error) {
    ErrorHandler.error(error.message);
  }
}

// Handler: Cambio de rol
function handleRoleChange(e) {
  const role = e.target.value;
  
  // Actualizar usuario actual (simulación)
  const users = {
    author: { id: 'user-author-1', role: 'author', name: 'Miguel Torres' },
    editor: { id: 'user-editor-1', role: 'editor', name: 'Dr. Carlos Martínez' },
    reviewer: { id: 'user-reviewer-1', role: 'reviewer', name: 'Dra. Ana Rodríguez' }
  };
  
  currentUser = users[role];
  console.log('Rol cambiado a:', currentUser.role);
  
  updateUIByRole();
  loadDataByRole();
}

// Handler: Cambio de filtro (editor)
async function handleFilterChange(e) {
  const status = e.target.dataset.status;
  currentFilter = status;
  
  document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.classList.remove('active');
  });
  e.target.classList.add('active');
  
  await loadEditorArticles();
}

// Handler: Abrir modal de asignación
window.openAssignReviewers = async (articleId) => {
  currentArticleForAssignment = articleId;
  
  try {
    const article = await ArticleManager.getArticleById(articleId);
    const reviewers = await db.reviewers.toArray();
    
    document.getElementById('assignArticleTitle').textContent = article.title;
    
    const container = document.getElementById('reviewersList');
    container.innerHTML = reviewers.map(reviewer => {
      const isAssigned = article.assignedReviewers.includes(reviewer.id);
      const isDisabled = !isAssigned && article.assignedReviewers.length >= 3;
      
      return `
        <label class="reviewer-checkbox ${isDisabled ? 'disabled' : ''}">
          <input 
            type="checkbox" 
            value="${reviewer.id}"
            ${isAssigned ? 'checked' : ''}
            ${isDisabled ? 'disabled' : ''}
          >
          <div class="reviewer-info">
            <strong>${reviewer.name}</strong>
            <p>Experticia: ${reviewer.expertise.join(', ')}</p>
            <p>Artículos asignados: ${reviewer.assignedArticles?.length || 0}</p>
          </div>
        </label>
      `;
    }).join('');
    
    document.getElementById('assignReviewersDialog').showModal();
    
  } catch (error) {
    ErrorHandler.error('Error abriendo asignación: ' + error.message);
  }
};

// Handler: Confirmar asignación
async function handleConfirmAssignment() {
  const checkboxes = document.querySelectorAll('#reviewersList input[type="checkbox"]:checked');
  const selectedReviewers = Array.from(checkboxes).map(cb => cb.value);
  
  if (selectedReviewers.length < 2) {
    ErrorHandler.error('Debe asignar al menos 2 revisores');
    return;
  }
  
  if (selectedReviewers.length > 3) {
    ErrorHandler.error('Máximo 3 revisores permitidos');
    return;
  }
  
  try {
    await ArticleManager.assignReviewers(
      currentArticleForAssignment,
      selectedReviewers,
      currentUser.id
    );
    
    ErrorHandler.success('Revisores asignados exitosamente');
    document.getElementById('assignReviewersDialog').close();
    await loadEditorArticles();
    
  } catch (error) {
    ErrorHandler.error(error.message);
  }
}

// Handler: Abrir formulario de revisión
window.openReviewForm = async (articleId) => {
  // TODO: Implementar apertura de formulario con carga de borrador si existe
  ErrorHandler.info('Función de revisión en desarrollo');
};

// Handler: Submit revisión
async function handleReviewSubmit(e) {
  e.preventDefault();
  await handleSaveReview('submitted');
}

// Handler: Guardar revisión (borrador o enviar)
async function handleSaveReview(status) {
  // TODO: Implementar guardado de revisión
  ErrorHandler.info(`Guardando revisión como ${status}...`);
}

// Actualizar contador de caracteres
function updateCharCount() {
  const textarea = document.getElementById('reviewComments');
  const counter = document.getElementById('commentsCharCount');
  if (textarea && counter) {
    const count = textarea.value.length;
    counter.textContent = `${count} / 100 caracteres mínimos`;
    counter.className = count >= 100 ? 'char-count-ok' : '';
  }
}

// ============================================
// FUNCIONES GLOBALES
// ============================================

window.downloadArticlePDF = async (id) => {
  await ArticleManager.downloadPDF(id);
};

window.viewArticleComments = async (id, role) => {
  await CommentSystem.openCommentsDialog(id, role);
};

window.viewMyReview = async (articleId) => {
  ErrorHandler.info('Ver revisión en desarrollo');
};

// ============================================
// UTILIDADES
// ============================================

function getStatusBadge(status) {
  const badges = {
    received: '<span class="badge badge-received">📨 Recibido</span>',
    in_review: '<span class="badge badge-in_review">📝 En Revisión</span>',
    reviewed: '<span class="badge badge-reviewed">✅ Revisado</span>',
    accepted: '<span class="badge badge-accepted">🎉 Aceptado</span>',
    rejected: '<span class="badge badge-rejected">❌ Rechazado</span>'
  };
  return badges[status] || '';
}

function getReviewStatusBadge(status) {
  const badges = {
    pending: '<span class="badge badge-warning">⏳ Pendiente</span>',
    draft: '<span class="badge badge-draft">📝 Borrador</span>',
    submitted: '<span class="badge badge-success">✅ Completada</span>'
  };
  return badges[status] || '';
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ============================================
// SISTEMA
// ============================================

function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => {
        console.log('✅ Service Worker registrado');
        document.getElementById('swStatus').textContent = '✅ Activo';
      })
      .catch(err => {
        console.error('❌ Error registrando SW:', err);
        document.getElementById('swStatus').textContent = '❌ Error';
      });
  } else {
    document.getElementById('swStatus').textContent = '❌ No soportado';
  }
}

async function checkSystemStatus() {
  if (window.matchMedia('(display-mode: standalone)').matches) {
    document.getElementById('pwaStatus').textContent = '✅ Sí';
  }
  
  try {
    await db.open();
    document.getElementById('dbStatus').textContent = '✅ Conectado';
  } catch (error) {
    document.getElementById('dbStatus').textContent = '❌ Error';
    ErrorHandler.error('Error conectando a IndexedDB');
  }
}

function setupNetworkDetection() {
  const indicator = document.getElementById('offlineIndicator');
  const statusSpan = document.getElementById('networkStatus');
  
  function updateNetworkStatus() {
    if (navigator.onLine) {
      indicator.classList.add('hidden');
      statusSpan.textContent = '🟢 Online';
    } else {
      indicator.classList.remove('hidden');
      statusSpan.textContent = '🔴 Offline';
    }
  }
  
  window.addEventListener('online', () => {
    updateNetworkStatus();
    ErrorHandler.info('Conexión restaurada');
  });
  
  window.addEventListener('offline', () => {
    updateNetworkStatus();
    ErrorHandler.warning('Sin conexión - Trabajando offline');
  });
  
  updateNetworkStatus();
}
