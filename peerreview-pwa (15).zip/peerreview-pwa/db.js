// ============================================================
// db.js — IndexedDB wrapper for offline caching
// ============================================================

const DB_NAME    = 'peerreview-db';
const DB_VERSION = 2;

const STORES = {
  articles:  { keyPath: 'id' },
  reviews:   { keyPath: 'id' },
  syncQueue: { keyPath: 'id', autoIncrement: true }
};

let _db = null;

export async function openDB() {
  if (_db) return _db;
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = e => {
      const db = e.target.result;
      Object.entries(STORES).forEach(([name, opts]) => {
        if (!db.objectStoreNames.contains(name))
          db.createObjectStore(name, opts);
      });
    };

    req.onsuccess = e  => { _db = e.target.result; resolve(_db); };
    req.onerror   = () => reject(req.error);
  });
}

// ── Generic CRUD ──────────────────────────────────────────────

export async function dbPut(store, item) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).put(item);
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

export async function dbGet(store, key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

export async function dbGetAll(store) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, 'readonly');
    const req = tx.objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

export async function dbDelete(store, key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).delete(key);
    req.onsuccess = () => resolve();
    req.onerror   = () => reject(req.error);
  });
}

export async function dbClear(store) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx  = db.transaction(store, 'readwrite');
    const req = tx.objectStore(store).clear();
    req.onsuccess = () => resolve();
    req.onerror   = () => reject(req.error);
  });
}

// ── SyncQueue helpers ─────────────────────────────────────────

export async function enqueueSync(item) {
  return dbPut('syncQueue', { ...item, ts: Date.now() });
}

export async function listSyncQueue() {
  return dbGetAll('syncQueue');
}

export async function removeSyncItem(id) {
  return dbDelete('syncQueue', id);
}
