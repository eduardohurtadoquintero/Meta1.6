// ============================================================
// loading-indicator.js
// ============================================================

export function setLoading(elementId, loading, emptyMessage = 'Sin resultados') {
  const el = document.getElementById(elementId);
  if (!el) return;

  if (loading) {
    el.innerHTML = `
      <div class="loading-state">
        <div class="spinner"></div>
        <span>Cargando…</span>
      </div>`;
  }
}

export function setEmpty(elementId, icon = '📭', message = 'Sin resultados', sub = '') {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.innerHTML = `
    <div class="empty-state">
      <span class="empty-icon">${icon}</span>
      <p style="color:var(--text-2);font-weight:500">${message}</p>
      ${sub ? `<p style="font-size:.8rem;margin-top:.3rem">${sub}</p>` : ''}
    </div>`;
}

export function setContent(elementId, html) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.innerHTML = html;
}
