// ============================================================
// PeerReview Backend v7.1 — persistencia en db.json
// ============================================================
const express    = require('express');
const cors       = require('cors');
const bodyParser = require('body-parser');
const crypto     = require('crypto');
const fs         = require('fs');
const path       = require('path');

const app    = express();
const PORT   = 3001;
const DB_FILE = path.join(__dirname, 'db.json');

app.use(cors({ origin:'*', methods:['GET','POST','PUT','DELETE','OPTIONS'], allowedHeaders:['Content-Type','Authorization'] }));
app.use(bodyParser.json({ limit:'20mb' }));
app.use(express.static(path.join(__dirname, '..'))); // Servir frontend estático
app.use((req,_,next)=>{ console.log('['+new Date().toISOString().slice(11,19)+'] '+req.method+' '+req.path); next(); });

// ── Persistencia ──────────────────────────────────────────────
const hash = p => crypto.createHash('sha256').update(p).digest('hex');
const uid  = p => p+'-'+crypto.randomBytes(4).toString('hex');

// Convierte Maps a objetos planos para JSON
function serialize(db){
  return {
    users:    Object.fromEntries(db.users),
    articles: Object.fromEntries(db.articles),
    reviews:  Object.fromEntries(db.reviews),
    replies:  Object.fromEntries(db.replies),
    sessions: Object.fromEntries(db.sessions),
  };
}

// Reconstruye Maps desde JSON
function deserialize(data){
  return {
    users:    new Map(Object.entries(data.users    ||{})),
    articles: new Map(Object.entries(data.articles ||{})),
    reviews:  new Map(Object.entries(data.reviews  ||{})),
    replies:  new Map(Object.entries(data.replies  ||{})),
    sessions: new Map(Object.entries(data.sessions ||{})),
  };
}

// Carga o crea la base de datos
function loadDb(){
  if(fs.existsSync(DB_FILE)){
    try{
      var data = JSON.parse(fs.readFileSync(DB_FILE,'utf8'));
      console.log('✅ db.json cargado');
      return deserialize(data);
    } catch(e){
      console.error('⚠ Error leyendo db.json, se crea uno nuevo:', e.message);
    }
  }
  return { users:new Map(), articles:new Map(), reviews:new Map(), replies:new Map(), sessions:new Map() };
}

// Guarda a disco (debounced para no escribir en cada petición)
var saveTimer = null;
function save(){
  clearTimeout(saveTimer);
  saveTimer = setTimeout(function(){
    try{
      fs.writeFileSync(DB_FILE, JSON.stringify(serialize(db), null, 2));
    } catch(e){ console.error('⚠ Error guardando db.json:', e.message); }
  }, 300);
}

var db = loadDb();

// ── Seed (solo si no hay usuarios) ───────────────────────────
if(db.users.size === 0){
  console.log('📦 Primera vez — creando usuarios seed...');
  [
    {id:'author-001',  email:'autor@test.com',    password:'autor123',   name:'Miguel Torres',       role:'author'},
    {id:'author-002',  email:'autor2@test.com',   password:'autor123',   name:'Sofia Reyes',         role:'author'},
    {id:'editor-001',  email:'editor@test.com',   password:'editor123',  name:'Dr. Carlos Martínez', role:'editor'},
    {id:'rev-001',     email:'revisor@test.com',  password:'revisor123', name:'Dra. Ana Rodríguez',  role:'reviewer'},
    {id:'rev-002',     email:'revisor2@test.com', password:'revisor123', name:'Dr. Luis Fernández',  role:'reviewer'},
    {id:'rev-003',     email:'revisor3@test.com', password:'revisor123', name:'Dra. Marta Solís',    role:'reviewer'},
  ].forEach(u=>db.users.set(u.id, Object.assign({},u,{password:hash(u.password),createdAt:Date.now()})));
  save();
} else {
  console.log('✅', db.users.size, 'usuarios cargados desde db.json');
  console.log('✅', db.articles.size, 'artículos, ', db.reviews.size, 'revisiones');
}

// Limpiar sesiones expiradas al arrancar
var now = Date.now();
var expired = 0;
db.sessions.forEach(function(s,k){ if(s.expiresAt < now){ db.sessions.delete(k); expired++; } });
if(expired > 0){ console.log('🗑 '+expired+' sesiones expiradas eliminadas'); save(); }

// ── Auth middleware ───────────────────────────────────────────
function auth(req,res,next){
  var h=req.headers.authorization;
  if(!h||!h.startsWith('Bearer ')) return res.status(401).json({error:'No autenticado'});
  var s=db.sessions.get(h.slice(7));
  if(!s) return res.status(401).json({error:'Sesión inválida'});
  if(s.expiresAt<Date.now()){ db.sessions.delete(h.slice(7)); save(); return res.status(401).json({error:'Sesión expirada'}); }
  req.userId=s.userId; req.user=db.users.get(s.userId); next();
}

// ── AUTH ──────────────────────────────────────────────────────
app.post('/api/auth/login',(req,res)=>{
  var u=Array.from(db.users.values()).find(u=>u.email===req.body.email);
  if(!u||u.password!==hash(req.body.password)) return res.status(401).json({error:'Credenciales inválidas'});
  var token=crypto.randomBytes(32).toString('hex');
  db.sessions.set(token,{userId:u.id,createdAt:Date.now(),expiresAt:Date.now()+86400000});
  save();
  var safe=Object.assign({},u); delete safe.password;
  res.json({success:true,token,user:safe});
});

app.post('/api/auth/logout',(req,res)=>{
  if(req.body&&req.body.token){ db.sessions.delete(req.body.token); save(); }
  res.json({success:true});
});

app.post('/api/auth/register',(req,res)=>{
  var {name,email,password,role}=req.body;
  if(!name||!email||!password||!role) return res.status(400).json({error:'Faltan campos'});
  if(!['author','reviewer'].includes(role)) return res.status(400).json({error:'Rol no permitido'});
  if(Array.from(db.users.values()).find(u=>u.email===email)) return res.status(409).json({error:'Email ya registrado'});
  var u={id:uid(role),email,password:hash(password),name,role,createdAt:Date.now()};
  db.users.set(u.id,u); save();
  res.status(201).json({success:true,userId:u.id});
});

// ── USERS ─────────────────────────────────────────────────────
app.get('/api/users/reviewers',auth,(_,res)=>{
  res.json(Array.from(db.users.values()).filter(u=>u.role==='reviewer').map(u=>{var s=Object.assign({},u);delete s.password;return s;}));
});

// ── ARTICLES ──────────────────────────────────────────────────
function stripPdf(a){ var c=Object.assign({},a); c.hasPdf=!!a.pdfData; delete c.pdfData; return c; }

app.get('/api/articles',auth,(req,res)=>{
  var list=Array.from(db.articles.values());
  if(req.user.role==='author')   list=list.filter(a=>a.authorId===req.userId);
  if(req.user.role==='reviewer') list=list.filter(a=>
    a.assignedReviewers&&a.assignedReviewers.includes(req.userId)&&
    ['in_review','reviewed'].includes(a.status)
  );
  res.json(list.map(stripPdf).sort((a,b)=>b.createdAt-a.createdAt));
});

app.post('/api/articles',auth,(req,res)=>{
  if(req.user.role!=='author') return res.status(403).json({error:'Solo autores'});
  var a=Object.assign({},req.body,{
    id:uid('article'), authorId:req.userId, authorName:req.user.name,
    status:'received', assignedReviewers:[], editorNotes:'', rejectionReason:'',
    createdAt:Date.now(), updatedAt:Date.now()
  });
  db.articles.set(a.id,a); save();
  res.status(201).json(stripPdf(a));
});

app.put('/api/articles/:id/decision',auth,(req,res)=>{
  if(req.user.role!=='editor') return res.status(403).json({error:'Solo editores'});
  var a=db.articles.get(req.params.id);
  if(!a) return res.status(404).json({error:'No encontrado'});
  var {decision,notes,checklist}=req.body;
  if(!['accepted','rejected'].includes(decision)) return res.status(400).json({error:'Decisión inválida'});
  a.status          = decision==='accepted' ? 'editor_accepted' : 'rejected';
  a.editorNotes     = notes||'';
  a.editorChecklist = checklist||{};
  a.rejectionReason = decision==='rejected'? (notes||'') : '';
  a.updatedAt       = Date.now();
  db.articles.set(a.id,a); save();
  res.json({success:true});
});

app.put('/api/articles/:id/resubmit',auth,(req,res)=>{
  if(req.user.role!=='author') return res.status(403).json({error:'Solo autores'});
  var a=db.articles.get(req.params.id);
  if(!a) return res.status(404).json({error:'No encontrado'});
  if(a.authorId!==req.userId) return res.status(403).json({error:'No autorizado'});
  if(a.status!=='rejected') return res.status(400).json({error:'Solo se pueden reenviar artículos rechazados'});
  if(req.body.pdfData)  a.pdfData  = req.body.pdfData;
  if(req.body.pdfName)  a.pdfName  = req.body.pdfName;
  if(req.body.abstract) a.abstract = req.body.abstract;
  a.status='received'; a.updatedAt=Date.now();
  db.articles.set(a.id,a); save();
  res.json({success:true});
});

app.put('/api/articles/:id/assign',auth,(req,res)=>{
  if(req.user.role!=='editor') return res.status(403).json({error:'Solo editores'});
  var a=db.articles.get(req.params.id);
  if(!a) return res.status(404).json({error:'No encontrado'});
  if(a.status!=='editor_accepted') return res.status(400).json({error:'Debes aceptar el artículo antes de asignar revisores'});
  a.assignedReviewers=req.body.reviewerIds; a.status='in_review'; a.updatedAt=Date.now();
  db.articles.set(a.id,a); save();
  res.json({success:true});
});

app.get('/api/articles/:id/pdf',auth,(req,res)=>{
  var a=db.articles.get(req.params.id);
  if(!a) return res.status(404).json({error:'No encontrado'});
  var canView=req.user.role==='editor'||a.authorId===req.userId||
    (a.assignedReviewers&&a.assignedReviewers.includes(req.userId)&&['in_review','reviewed'].includes(a.status));
  if(!canView) return res.status(403).json({error:'Sin acceso al PDF'});
  if(!a.pdfData) return res.status(404).json({error:'Sin PDF adjunto'});
  res.json({pdfData:a.pdfData,fileName:a.pdfName||'documento.pdf'});
});

// ── REVIEWS ───────────────────────────────────────────────────
app.get('/api/reviews/:articleId',auth,(req,res)=>{
  var reviews=Array.from(db.reviews.values()).filter(r=>r.articleId===req.params.articleId);
  if(req.user.role==='author')   reviews=reviews.map(r=>{var c=Object.assign({},r);delete c.editorComment;return c;});
  if(req.user.role==='reviewer') reviews=reviews.filter(r=>r.reviewerId===req.userId);
  res.json(reviews);
});

app.post('/api/reviews',auth,(req,res)=>{
  if(req.user.role!=='reviewer') return res.status(403).json({error:'Solo revisores'});
  if(Array.from(db.reviews.values()).find(r=>r.articleId===req.body.articleId&&r.reviewerId===req.userId))
    return res.status(409).json({error:'Ya revisaste este artículo'});
  var r=Object.assign({},req.body,{
    id:uid('review'), reviewerId:req.userId, reviewerName:req.user.name,
    status:'submitted', submittedAt:Date.now(), createdAt:Date.now()
  });
  db.reviews.set(r.id,r);
  var a=db.articles.get(r.articleId);
  if(a){
    var done=Array.from(db.reviews.values()).filter(rv=>rv.articleId===r.articleId&&rv.status==='submitted');
    if(done.length>=a.assignedReviewers.length){ a.status='reviewed'; db.articles.set(a.id,a); }
  }
  save();
  res.status(201).json(r);
});

// ── REPLIES ───────────────────────────────────────────────────
app.get('/api/replies/:reviewId',auth,(req,res)=>{
  res.json(Array.from(db.replies.values()).filter(r=>r.reviewId===req.params.reviewId).sort((a,b)=>a.createdAt-b.createdAt));
});

app.post('/api/replies',auth,(req,res)=>{
  if(req.user.role!=='author') return res.status(403).json({error:'Solo autores pueden responder'});
  var {reviewId,message}=req.body;
  if(!reviewId||!message) return res.status(400).json({error:'Faltan campos'});
  var reply={id:uid('reply'),reviewId,authorId:req.userId,authorName:req.user.name,message,createdAt:Date.now()};
  db.replies.set(reply.id,reply); save();
  res.status(201).json(reply);
});

// ── HEALTH ────────────────────────────────────────────────────
app.get('/health',(_,res)=>res.json({
  status:'ok', ts:new Date().toISOString(), version:'7.1',
  db:{users:db.users.size, articles:db.articles.size, reviews:db.reviews.size, replies:db.replies.size}
}));

app.use((req,res)=>res.status(404).json({error:'No encontrado: '+req.method+' '+req.path}));
app.use((err,_,res,__)=>{ console.error(err); res.status(500).json({error:err.message}); });

app.listen(PORT,'0.0.0.0',()=>{
  console.log('='.repeat(50));
  console.log('🚀 PeerReview Backend v7.1');
  console.log('📡 http://localhost:'+PORT);
  console.log('💾 Datos guardados en: '+DB_FILE);
  console.log('='.repeat(50));
});

// Guardar al cerrar limpiamente
process.on('SIGINT',()=>{ console.log('\n💾 Guardando datos...'); fs.writeFileSync(DB_FILE,JSON.stringify(serialize(db),null,2)); console.log('👋 ¡Hasta luego!'); process.exit(0); });
process.on('SIGTERM',()=>{ fs.writeFileSync(DB_FILE,JSON.stringify(serialize(db),null,2)); process.exit(0); });
