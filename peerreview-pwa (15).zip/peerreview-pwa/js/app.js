// ============================================================
// app.js — PeerReview PWA v7.0
// ============================================================

var BACKEND_IP = null; // ya no se necesita cambiar manualmente

var API_URL = (function(){
  var h = window.location.hostname;
  // Local → apunta directo al puerto 3001
  if(h === '127.0.0.1' || h === 'localhost' || h === '')
    return 'http://localhost:3001/api';
  // ngrok / red pública → mismo origen, sin puerto
  return window.location.protocol + '//' + window.location.host + '/api';
})();
console.log('[PeerReview] API →', API_URL);

var authToken = null, currentUser = null;

// ── Rúbrica académica ─────────────────────────────────────────
var RUBRIC = {
  criteria:[
    {id:'argument',    name:'Argumentación',     desc:'Solidez, coherencia y profundidad de los argumentos presentados',           weight:0.25},
    {id:'sources',     name:'Fuentes y citas',    desc:'Calidad, pertinencia y correcta citación de las referencias bibliográficas', weight:0.25},
    {id:'contribution',name:'Aporte académico',   desc:'Originalidad y contribución real al campo de conocimiento',                  weight:0.20},
    {id:'methodology', name:'Metodología',        desc:'Rigor y adecuación del método de investigación empleado',                    weight:0.20},
    {id:'clarity',     name:'Claridad expositiva',desc:'Claridad, organización lógica y calidad de la redacción académica',          weight:0.10},
  ],
  scale:[
    {value:5,label:'Excelente',  stars:'★★★★★'},
    {value:4,label:'Bueno',      stars:'★★★★☆'},
    {value:3,label:'Aceptable',  stars:'★★★☆☆'},
    {value:2,label:'Deficiente', stars:'★★☆☆☆'},
    {value:1,label:'Insuficiente',stars:'★☆☆☆☆'},
  ]
};

// Checklist del editor
var EDITOR_CHECKLIST = [
  {id:'structure',  label:'Estructura del documento (introducción, desarrollo, conclusiones)'},
  {id:'format',     label:'Formato adecuado (márgenes, tipografía, interlineado)'},
  {id:'citations',  label:'Normas de citación correctas (APA/IEEE/MLA)'},
  {id:'abstract',   label:'Resumen / Abstract presente y bien redactado'},
  {id:'keywords',   label:'Palabras clave incluidas'},
  {id:'references', label:'Lista de referencias bibliográficas completa'},
  {id:'figures',    label:'Figuras y tablas numeradas y referenciadas en el texto'},
  {id:'language',   label:'Lenguaje académico apropiado y sin errores graves'},
];

function computeScore(scores){
  var t=0; scores=scores||{};
  RUBRIC.criteria.forEach(function(c){ t+=(scores[c.id]||0)*c.weight; });
  return t.toFixed(2);
}

function renderRubricForm(){
  return RUBRIC.criteria.map(function(c){
    var opts=RUBRIC.scale.map(function(s){
      return '<span>'+
        '<input type="radio" class="rating-opt" id="r_'+c.id+'_'+s.value+'" name="'+c.id+'" value="'+s.value+'">'+
        '<label class="rating-lbl" for="r_'+c.id+'_'+s.value+'">'+
          '<span class="stars">'+s.stars+'</span>'+
          '<span>'+s.value+'</span>'+
          '<span style="font-size:.65rem">'+s.label+'</span>'+
        '</label></span>';
    }).join('');
    return '<div class="rubric-criterion">'+
      '<div class="criterion-header">'+
        '<span class="criterion-name">📊 '+c.name+'</span>'+
        '<span class="criterion-weight">'+(c.weight*100).toFixed(0)+'% peso</span>'+
      '</div>'+
      '<p class="criterion-desc">'+c.desc+'</p>'+
      '<div class="rating-row">'+opts+'</div>'+
    '</div>';
  }).join('');
}

// ── Utils ─────────────────────────────────────────────────────
function esc(s){ var d=document.createElement('div'); d.textContent=String(s||''); return d.innerHTML; }
function get(id){ return document.getElementById(id); }

function showToast(msg,type){
  type=type||'info';
  var c=get('toastContainer'); if(!c) return;
  var t=document.createElement('div');
  t.className='toast toast-'+type;
  t.innerHTML='<span>'+{success:'✓',error:'✕',info:'ℹ',warning:'⚠'}[type]+'</span><span>'+esc(msg)+'</span>';
  c.appendChild(t);
  setTimeout(function(){
    t.style.cssText+='opacity:0;transform:translateX(40px);transition:.3s';
    setTimeout(function(){ if(t.parentNode) t.parentNode.removeChild(t); },300);
  },4500);
}

function showError(id,msg){ var el=get(id); if(!el)return; el.innerHTML='<div class="alert alert-error">⚠ '+esc(msg)+'</div>'; el.classList.remove('hidden'); }
function clearError(id){ var el=get(id); if(!el)return; el.innerHTML=''; el.classList.add('hidden'); }
function setLoading(id){ var el=get(id); if(el) el.innerHTML='<div class="loading-state"><div class="spinner"></div><span>Cargando…</span></div>'; }
function setEmpty(id,icon,msg,sub){ var el=get(id); if(!el)return; el.innerHTML='<div class="empty-state"><span class="empty-icon">'+icon+'</span><p style="color:var(--text-2);font-weight:500">'+msg+'</p>'+(sub?'<p style="font-size:.8rem;margin-top:.3rem">'+sub+'</p>':'')+'</div>'; }

function statusLabel(s){
  return {
    received:      '📨 Recibido',
    editor_accepted:'✅ Aceptado por editor',
    rejected:      '❌ Rechazado',
    in_review:     '📝 En revisión',
    reviewed:      '✅ Revisado'
  }[s]||s;
}

function statusBadgeClass(s){
  return {
    received:'badge-received', editor_accepted:'badge-accepted',
    rejected:'badge-rejected', in_review:'badge-in_review', reviewed:'badge-reviewed'
  }[s]||'';
}

function fileToBase64(file){
  return new Promise(function(resolve,reject){
    var r=new FileReader();
    r.onload=function(e){ resolve(e.target.result.split(',')[1]); };
    r.onerror=function(){ reject(new Error('Error leyendo archivo')); };
    r.readAsDataURL(file);
  });
}

// ── API ───────────────────────────────────────────────────────
function api(endpoint,opts){
  opts=opts||{};
  var headers={'Content-Type':'application/json'};
  if(opts.headers) Object.assign(headers,opts.headers);
  if(authToken) headers['Authorization']='Bearer '+authToken;
  return fetch(API_URL+endpoint,Object.assign({},opts,{headers:headers}))
    .catch(function(){ throw new Error('Sin conexión al backend. ¿Está corriendo "npm start"? ('+API_URL+')'); })
    .then(function(res){
      var ct=res.headers.get('content-type')||'';
      if(!ct.includes('application/json')) throw new Error('Servidor no devolvió JSON (código '+res.status+')');
      return res.json().then(function(data){ if(!res.ok) throw new Error(data.error||'Error '+res.status); return data; });
    });
}

// ── Modal ─────────────────────────────────────────────────────
function openModal(title,html){ get('modalTitle').textContent=title; get('modalBody').innerHTML=html; get('modal').classList.add('open'); }
function closeModal(){ get('modal').classList.remove('open'); }

// Globales para onclick en HTML generado
window.closeModal=closeModal; window.viewReviews=viewReviews; window.assignReviewers=assignReviewers;
window.loadEditorArticles=loadEditorArticles; window.loadReviewerArticles=loadReviewerArticles;
window.loadAuthorArticles=loadAuthorArticles; window.viewPdf=viewPdf;
window.openReviewModal=openReviewModal; window.viewMyReview=viewMyReview;
window.editorDecision=editorDecision; window.resubmitArticle=resubmitArticle;

// ══════════════════════════════════════════════════════════════
// INIT
// ══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded',function(){
  console.log('[PeerReview] DOM listo, API:', API_URL);

  get('modalCloseBtn').addEventListener('click',closeModal);
  get('modal').addEventListener('click',function(e){ if(e.target===get('modal')) closeModal(); });

  function updateSync(){ var on=navigator.onLine; get('syncDot').className=on?'sync-dot':'sync-dot offline'; get('syncStatus').textContent=on?'online':'offline'; }
  window.addEventListener('online',updateSync); window.addEventListener('offline',updateSync); updateSync();

  // Tabs
  document.querySelectorAll('.login-tab').forEach(function(tab){
    tab.addEventListener('click',function(){
      document.querySelectorAll('.login-tab').forEach(function(t){ t.classList.remove('active'); });
      tab.classList.add('active');
      var target=tab.dataset.tab;
      get('loginPanel').classList.toggle('hidden',target!=='login');
      get('registerPanel').classList.toggle('hidden',target!=='register');
    });
  });

  // Demo chips
  document.querySelectorAll('.demo-chip').forEach(function(chip){
    chip.addEventListener('click',function(){
      get('lEmail').value=chip.dataset.email; get('lPassword').value=chip.dataset.pwd;
      document.querySelectorAll('.login-tab').forEach(function(t){ t.classList.remove('active'); });
      document.querySelector('.login-tab[data-tab="login"]').classList.add('active');
      get('loginPanel').classList.remove('hidden'); get('registerPanel').classList.add('hidden');
    });
  });

  // LOGIN
  function doLogin(){
    clearError('loginErrorWrap');
    var email=get('lEmail').value.trim(), password=get('lPassword').value;
    if(!email||!password){ showError('loginErrorWrap','Escribe tu correo y contraseña.'); return; }
    var btn=get('loginBtn'); btn.disabled=true; btn.textContent='Iniciando…';
    api('/auth/login',{method:'POST',body:JSON.stringify({email,password})})
      .then(function(d){ authToken=d.token; currentUser=d.user; enterApp(); })
      .catch(function(e){ showError('loginErrorWrap',e.message); })
      .finally(function(){ btn.disabled=false; btn.textContent='Iniciar sesión'; });
  }
  get('loginBtn').addEventListener('click',doLogin);
  get('lEmail').addEventListener('keydown',function(e){ if(e.key==='Enter') doLogin(); });
  get('lPassword').addEventListener('keydown',function(e){ if(e.key==='Enter') doLogin(); });

  // REGISTER
  get('registerBtn').addEventListener('click',function(){
    clearError('registerErrorWrap');
    var name=get('rName').value.trim(),email=get('rEmail').value.trim(),pwd=get('rPassword').value,role=get('rRole').value;
    if(!name||!email||!pwd||!role){ showError('registerErrorWrap','Completa todos los campos.'); return; }
    if(pwd.length<6){ showError('registerErrorWrap','Contraseña mínimo 6 caracteres.'); return; }
    var btn=get('registerBtn'); btn.disabled=true; btn.textContent='Registrando…';
    api('/auth/register',{method:'POST',body:JSON.stringify({name,email,password:pwd,role})})
      .then(function(){
        showToast('Cuenta creada. Ahora inicia sesión.','success');
        get('lEmail').value=email;
        document.querySelector('.login-tab[data-tab="login"]').click();
        get('rName').value=get('rEmail').value=get('rPassword').value=''; get('rRole').value='';
      })
      .catch(function(e){ showError('registerErrorWrap',e.message); })
      .finally(function(){ btn.disabled=false; btn.textContent='Crear cuenta'; });
  });

  // LOGOUT
  get('logoutBtn').addEventListener('click',function(){
    api('/auth/logout',{method:'POST',body:JSON.stringify({token:authToken})})
      .catch(function(){})
      .finally(function(){
        authToken=currentUser=null;
        get('loginScreen').style.display=''; get('appScreen').style.display='none';
        get('lEmail').value=get('lPassword').value=''; get('appContent').innerHTML='';
        clearError('loginErrorWrap');
      });
  });

  console.log('[PeerReview] ✅ Listeners OK');
});

// ── Enter app ─────────────────────────────────────────────────
function enterApp(){
  get('loginScreen').style.display='none'; get('appScreen').style.display='block';
  var initials=currentUser.name.split(' ').map(function(n){return n[0];}).join('').slice(0,2).toUpperCase();
  var av=get('headerAvatar'); av.textContent=initials; av.className='user-avatar '+currentUser.role;
  get('headerName').textContent=currentUser.name; get('headerRole').textContent=currentUser.role;
  if(currentUser.role==='author')   renderAuthor();
  if(currentUser.role==='editor')   renderEditor();
  if(currentUser.role==='reviewer') renderReviewer();
}

// ══════════════════════════════════════════════════════════════
// AUTHOR
// ══════════════════════════════════════════════════════════════
function renderAuthor(){
  get('appContent').innerHTML=
    '<div class="card">'+
      '<div class="card-title">📤 Enviar artículo</div>'+
      '<div class="form-group"><label>Título *</label><input type="text" id="aTitle" maxlength="200" placeholder="Título del artículo…"></div>'+
      '<div class="form-group"><label>Área *</label>'+
        '<select id="aArea"><option value="">Selecciona…</option>'+
          '<option>Inteligencia Artificial</option><option>Machine Learning</option>'+
          '<option>Ciencia de Datos</option><option>Ciberseguridad</option>'+
          '<option>Ingeniería de Software</option><option>Redes</option>'+
        '</select></div>'+
      '<div class="form-group"><label>Resumen</label><textarea id="aAbstract" rows="4" placeholder="Descripción breve…"></textarea></div>'+
      '<div class="form-group">'+
        '<label>📎 Documento PDF <span style="font-size:.75rem;color:var(--text-3);font-weight:400">(recomendado, máx. 10 MB)</span></label>'+
        '<div id="pdfDropZone" style="border:2px dashed var(--border);border-radius:var(--radius);padding:1.5rem;text-align:center;cursor:pointer;transition:border-color .2s;color:var(--text-3)">'+
          '<div style="font-size:1.5rem;margin-bottom:.5rem">📄</div>'+
          '<div id="pdfLabel">Haz clic aquí o arrastra un PDF</div>'+
        '</div>'+
        '<input type="file" id="pdfInput" accept="application/pdf" style="display:none">'+
      '</div>'+
      '<button type="button" id="submitArticleBtn" class="btn btn-primary">📤 Enviar artículo</button>'+
    '</div>'+
    '<div class="card">'+
      '<div class="card-title" style="justify-content:space-between">📊 Mis artículos'+
        '<button class="btn btn-secondary btn-sm" onclick="loadAuthorArticles()">↻ Actualizar</button>'+
      '</div>'+
      '<div id="authorArticles"></div>'+
    '</div>';

  // PDF drop zone
  var dz=get('pdfDropZone'), pi=get('pdfInput');
  dz.addEventListener('click',function(){ pi.click(); });
  dz.addEventListener('dragover',function(e){ e.preventDefault(); dz.style.borderColor='var(--accent)'; });
  dz.addEventListener('dragleave',function(){ dz.style.borderColor='var(--border)'; });
  dz.addEventListener('drop',function(e){ e.preventDefault(); dz.style.borderColor='var(--border)'; var f=e.dataTransfer.files[0]; if(f) handlePdfSelect(f); });
  pi.addEventListener('change',function(){ if(pi.files[0]) handlePdfSelect(pi.files[0]); });

  function handlePdfSelect(file){
    if(file.type!=='application/pdf'){ showToast('Solo se permiten archivos PDF','error'); return; }
    if(file.size>10*1024*1024){ showToast('El PDF no puede superar 10 MB','error'); return; }
    get('pdfLabel').textContent='✅ '+file.name+' ('+(file.size/1024).toFixed(0)+' KB)';
    dz.style.borderColor='var(--green)'; dz._file=file;
  }

  get('submitArticleBtn').addEventListener('click',function(){
    var title=get('aTitle').value.trim(), area=get('aArea').value, abstract=get('aAbstract').value.trim();
    if(!title||!area){ showToast('Escribe el título y selecciona el área','error'); return; }
    var btn=get('submitArticleBtn'); btn.disabled=true; btn.textContent='Enviando…';
    var file=get('pdfDropZone')._file;
    var doSend=function(b64,fname){
      api('/articles',{method:'POST',body:JSON.stringify({title,area,abstract,pdfData:b64||null,pdfName:fname||null})})
        .then(function(){ showToast('Artículo enviado. El editor lo revisará pronto.','success'); get('aTitle').value=get('aAbstract').value=''; get('aArea').value=''; get('pdfLabel').textContent='Haz clic aquí o arrastra un PDF'; get('pdfDropZone').style.borderColor='var(--border)'; get('pdfDropZone')._file=null; loadAuthorArticles(); })
        .catch(function(e){ showToast(e.message,'error'); })
        .finally(function(){ btn.disabled=false; btn.textContent='📤 Enviar artículo'; });
    };
    if(file) fileToBase64(file).then(function(b64){ doSend(b64,file.name); }).catch(function(e){ showToast(e.message,'error'); btn.disabled=false; btn.textContent='📤 Enviar artículo'; });
    else doSend(null,null);
  });

  loadAuthorArticles();
}

function loadAuthorArticles(){
  setLoading('authorArticles');
  api('/articles').then(function(arts){
    if(!arts.length){ setEmpty('authorArticles','📭','Aún no has enviado artículos','Usa el formulario de arriba.'); return; }
    var c=get('authorArticles');
    c.innerHTML=arts.map(function(a){
      var actions='';
      if(a.hasPdf) actions+='<button class="btn btn-secondary btn-sm pdf-btn">📄 Ver PDF</button>';
      if(a.status==='in_review'||a.status==='reviewed') actions+='<button class="btn btn-primary btn-sm reviews-btn">💬 Ver revisiones</button>';
      if(a.status==='rejected') actions+='<button class="btn btn-warning btn-sm resubmit-btn">✏️ Corregir y reenviar</button>';
      return '<div class="article-item">'+
        '<div class="article-item-title">'+esc(a.title)+'</div>'+
        '<div class="article-item-meta">'+
          '<span>📂 '+esc(a.area)+'</span>'+
          '<span>🗓 '+new Date(a.createdAt).toLocaleDateString('es-ES')+'</span>'+
          (a.hasPdf?'<span style="color:var(--accent)">📄 PDF</span>':'')+
        '</div>'+
        (a.status==='rejected'&&a.rejectionReason?
          '<div class="rejection-note">❌ <strong>Motivo de rechazo:</strong> '+esc(a.rejectionReason)+'</div>':'')+
        '<div class="article-item-footer">'+
          '<div class="btn-group" data-id="'+a.id+'">'+actions+'</div>'+
          '<span class="badge '+statusBadgeClass(a.status)+'">'+statusLabel(a.status)+'</span>'+
        '</div>'+
      '</div>';
    }).join('');
    c.addEventListener('click',function(e){
      var btn=e.target.closest('button'); if(!btn)return;
      var g=btn.closest('[data-id]'); if(!g)return;
      var id=g.dataset.id;
      if(btn.classList.contains('pdf-btn'))      viewPdf(id);
      if(btn.classList.contains('reviews-btn'))  viewReviewsAuthor(id);
      if(btn.classList.contains('resubmit-btn')) resubmitArticle(id);
    });
  }).catch(function(e){ get('authorArticles').innerHTML='<div class="alert alert-error">'+esc(e.message)+'</div>'; });
}

// Autor ve sus revisiones con opción de responder
function viewReviewsAuthor(articleId){
  api('/reviews/'+articleId).then(function(reviews){
    if(!reviews.length){ showToast('Sin revisiones aún','info'); return; }
    var html=reviews.map(function(r,i){
      return '<div class="review-card">'+
        '<div class="review-card-header">'+
          '<div>'+
            '<div class="review-card-name">Revisor '+(i+1)+'</div>'+
            '<div class="review-card-date">'+new Date(r.submittedAt).toLocaleString('es-ES')+'</div>'+
          '</div>'+
          '<div style="text-align:center;background:var(--bg-hover);padding:.5rem 1rem;border-radius:var(--radius-sm);border:1px solid var(--border)">'+
            '<div style="font-family:var(--font-serif);font-size:1.6rem;color:var(--accent)">'+computeScore(r.scores)+'</div>'+
            '<div style="font-size:.7rem;color:var(--text-3)">/ 5.00</div>'+
          '</div>'+
        '</div>'+
        '<div class="score-grid">'+
          RUBRIC.criteria.map(function(c){
            return '<div class="score-cell"><div class="score-cell-label">'+c.name+'</div>'+
              '<div class="score-cell-value">'+((r.scores&&r.scores[c.id])||'—')+'<span style="font-size:.7rem;color:var(--text-3)">/5</span></div></div>';
          }).join('')+
        '</div>'+
        '<div class="comment-block">'+
          '<div class="comment-block-title">💬 Comentarios del revisor</div>'+
          '<p style="font-size:.875rem;color:var(--text-2);line-height:1.65">'+esc(r.comments)+'</p>'+
        '</div>'+
        (r.editorComment?
          '<div class="comment-block confidential">'+
            '<div class="comment-block-title">🔒 Comentarios del editor</div>'+
            '<p style="font-size:.875rem;color:var(--text-2);line-height:1.65">'+esc(r.editorComment)+'</p>'+
          '</div>':'')+
        // Respuestas anteriores
        '<div id="replies-'+r.id+'" class="replies-thread"></div>'+
        // Formulario de respuesta
        '<div class="reply-form">'+
          '<div class="form-group" style="margin-bottom:.5rem">'+
            '<textarea id="replyText-'+r.id+'" rows="3" placeholder="Escribe tu respuesta al revisor…" style="font-size:.85rem"></textarea>'+
          '</div>'+
          '<button type="button" class="btn btn-primary btn-sm send-reply-btn" data-review-id="'+r.id+'">📩 Responder</button>'+
        '</div>'+
      '</div>';
    }).join('');
    openModal('Revisiones ('+reviews.length+')',html);

    // Cargar respuestas existentes y bind botones
    reviews.forEach(function(r){
      loadReplies(r.id);
      var btn=document.querySelector('.send-reply-btn[data-review-id="'+r.id+'"]');
      if(btn) btn.addEventListener('click',function(){
        var txt=get('replyText-'+r.id).value.trim();
        if(!txt){ showToast('Escribe un mensaje antes de enviar','error'); return; }
        btn.disabled=true; btn.textContent='Enviando…';
        api('/replies',{method:'POST',body:JSON.stringify({reviewId:r.id,message:txt})})
          .then(function(){ get('replyText-'+r.id).value=''; loadReplies(r.id); showToast('Respuesta enviada','success'); })
          .catch(function(e){ showToast(e.message,'error'); })
          .finally(function(){ btn.disabled=false; btn.textContent='📩 Responder'; });
      });
    });
  }).catch(function(e){ showToast(e.message,'error'); });
}

function loadReplies(reviewId){
  var container=get('replies-'+reviewId); if(!container)return;
  api('/replies/'+reviewId).then(function(replies){
    if(!replies.length){ container.innerHTML=''; return; }
    container.innerHTML='<div class="replies-header">Respuestas del autor:</div>'+
      replies.map(function(rep){
        return '<div class="reply-item">'+
          '<div class="reply-meta">'+esc(rep.authorName)+' · '+new Date(rep.createdAt).toLocaleString('es-ES')+'</div>'+
          '<div class="reply-msg">'+esc(rep.message)+'</div>'+
        '</div>';
      }).join('');
  });
}

// Reenvío tras corrección
function resubmitArticle(articleId){
  openModal('✏️ Corregir y reenviar',
    '<p style="color:var(--text-3);font-size:.85rem;margin-bottom:1rem">Puedes subir un PDF corregido y actualizar el resumen antes de reenviar.</p>'+
    '<div class="form-group"><label>Resumen (opcional)</label><textarea id="resubAbstract" rows="3" placeholder="Actualiza el resumen si lo deseas…"></textarea></div>'+
    '<div class="form-group">'+
      '<label>📎 PDF corregido (opcional)</label>'+
      '<div id="resubDropZone" style="border:2px dashed var(--border);border-radius:var(--radius);padding:1rem;text-align:center;cursor:pointer;color:var(--text-3)">'+
        '<div id="resubPdfLabel">Haz clic aquí o arrastra el PDF corregido</div>'+
      '</div>'+
      '<input type="file" id="resubPdfInput" accept="application/pdf" style="display:none">'+
    '</div>'+
    '<div class="btn-group" style="margin-top:1rem">'+
      '<button type="button" id="doResubmitBtn" class="btn btn-primary">📤 Reenviar artículo</button>'+
      '<button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>'+
    '</div>'
  );
  var rdz=get('resubDropZone'), rpi=get('resubPdfInput');
  rdz.addEventListener('click',function(){ rpi.click(); });
  rdz.addEventListener('dragover',function(e){ e.preventDefault(); rdz.style.borderColor='var(--accent)'; });
  rdz.addEventListener('dragleave',function(){ rdz.style.borderColor='var(--border)'; });
  rdz.addEventListener('drop',function(e){ e.preventDefault(); rdz.style.borderColor='var(--border)'; var f=e.dataTransfer.files[0]; if(f) handleResub(f); });
  rpi.addEventListener('change',function(){ if(rpi.files[0]) handleResub(rpi.files[0]); });
  function handleResub(file){ if(file.type!=='application/pdf'){ showToast('Solo PDF','error'); return; } get('resubPdfLabel').textContent='✅ '+file.name; rdz.style.borderColor='var(--green)'; rdz._file=file; }

  get('doResubmitBtn').addEventListener('click',function(){
    var btn=get('doResubmitBtn'); btn.disabled=true; btn.textContent='Enviando…';
    var abstract=get('resubAbstract').value.trim();
    var file=get('resubDropZone')._file;
    var doSend=function(b64,fname){
      api('/articles/'+articleId+'/resubmit',{method:'PUT',body:JSON.stringify({abstract:abstract||undefined,pdfData:b64||undefined,pdfName:fname||undefined})})
        .then(function(){ showToast('Artículo reenviado al editor','success'); closeModal(); loadAuthorArticles(); })
        .catch(function(e){ showToast(e.message,'error'); })
        .finally(function(){ btn.disabled=false; btn.textContent='📤 Reenviar artículo'; });
    };
    if(file) fileToBase64(file).then(function(b64){ doSend(b64,file.name); }).catch(function(e){ showToast(e.message,'error'); btn.disabled=false; btn.textContent='📤 Reenviar artículo'; });
    else doSend(null,null);
  });
}

// ══════════════════════════════════════════════════════════════
// EDITOR
// ══════════════════════════════════════════════════════════════
function renderEditor(){
  get('appContent').innerHTML=
    '<div class="editor-tabs">'+
      '<button class="etab active" data-etab="pending">📨 Nuevos (por revisar)</button>'+
      '<button class="etab" data-etab="accepted">✅ Aceptados</button>'+
      '<button class="etab" data-etab="inreview">📝 En revisión / Revisados</button>'+
      '<button class="etab" data-etab="rejected">❌ Rechazados</button>'+
    '</div>'+
    '<div class="card"><div id="editorArticles"></div></div>';

  document.querySelectorAll('.etab').forEach(function(tab){
    tab.addEventListener('click',function(){
      document.querySelectorAll('.etab').forEach(function(t){ t.classList.remove('active'); });
      tab.classList.add('active');
      loadEditorArticles(tab.dataset.etab);
    });
  });
  loadEditorArticles('pending');
}

function loadEditorArticles(filter){
  filter=filter||'pending';
  setLoading('editorArticles');
  api('/articles').then(function(arts){
    var filtered=arts.filter(function(a){
      if(filter==='pending')   return a.status==='received';
      if(filter==='accepted')  return a.status==='editor_accepted';
      if(filter==='inreview')  return ['in_review','reviewed'].includes(a.status);
      if(filter==='rejected')  return a.status==='rejected';
      return true;
    });
    if(!filtered.length){ setEmpty('editorArticles','📭','Sin artículos en esta categoría'); return; }
    var c=get('editorArticles');
    c.innerHTML=filtered.map(function(a){
      var actions='';
      if(a.hasPdf) actions+='<button class="btn btn-secondary btn-sm pdf-btn">📄 Ver PDF</button>';
      if(a.status==='received') actions+=
        '<button class="btn btn-success btn-sm accept-btn">✅ Aceptar</button>'+
        '<button class="btn btn-danger btn-sm reject-btn">❌ Rechazar</button>';
      if(a.status==='editor_accepted') actions+=
        '<button class="btn btn-primary btn-sm assign-btn">👥 Asignar revisores</button>';
      if(['in_review','reviewed'].includes(a.status)) actions+=
        '<button class="btn btn-secondary btn-sm reviews-editor-btn">💬 Ver revisiones</button>';
      return '<div class="article-item">'+
        '<div class="article-item-title">'+esc(a.title)+'</div>'+
        '<div class="article-item-meta">'+
          '<span>👤 '+esc(a.authorName||'')+'</span>'+
          '<span>📂 '+esc(a.area)+'</span>'+
          '<span>🗓 '+new Date(a.createdAt).toLocaleDateString('es-ES')+'</span>'+
          (a.hasPdf?'<span style="color:var(--accent)">📄 PDF</span>':'')+
        '</div>'+
        '<div class="article-item-footer">'+
          '<div class="btn-group" data-id="'+a.id+'">'+actions+'</div>'+
          '<span class="badge '+statusBadgeClass(a.status)+'">'+statusLabel(a.status)+'</span>'+
        '</div>'+
      '</div>';
    }).join('');

    c.addEventListener('click',function(e){
      var btn=e.target.closest('button'); if(!btn)return;
      var g=btn.closest('[data-id]'); if(!g)return;
      var id=g.dataset.id;
      if(btn.classList.contains('pdf-btn'))           viewPdf(id);
      if(btn.classList.contains('accept-btn'))        editorDecision(id,'accepted');
      if(btn.classList.contains('reject-btn'))        editorDecision(id,'rejected');
      if(btn.classList.contains('assign-btn'))        assignReviewers(id);
      if(btn.classList.contains('reviews-editor-btn'))viewReviews(id,true);
    });
  }).catch(function(e){ get('editorArticles').innerHTML='<div class="alert alert-error">'+esc(e.message)+'</div>'; });
}

function editorDecision(articleId, decision){
  var isAccept = decision==='accepted';
  var checklistHtml = isAccept
    ? '<div style="margin-bottom:1.25rem"><div style="font-weight:500;color:var(--text-1);margin-bottom:.75rem">✅ Checklist de formato</div>'+
      EDITOR_CHECKLIST.map(function(item){
        return '<label style="display:flex;align-items:center;gap:.5rem;padding:.4rem 0;cursor:pointer">'+
          '<input type="checkbox" class="checklist-item" data-item="'+item.id+'" style="width:auto;accent-color:var(--green)">'+
          '<span style="font-size:.85rem;color:var(--text-2)">'+item.label+'</span>'+
        '</label>';
      }).join('')+'</div>'
    : '';
  openModal(
    isAccept ? '✅ Aceptar artículo' : '❌ Rechazar artículo',
    checklistHtml+
    '<div class="form-group">'+
      '<label>'+(isAccept?'Notas para los revisores (opcional)':'Motivo del rechazo *')+'</label>'+
      '<textarea id="decisionNotes" rows="4" placeholder="'+(isAccept?'Instrucciones adicionales para los revisores…':'Explica al autor qué debe corregir…')+'"></textarea>'+
    '</div>'+
    '<div class="btn-group" style="margin-top:1rem">'+
      '<button type="button" id="confirmDecisionBtn" class="btn '+(isAccept?'btn-success':'btn-danger')+'">'+
        (isAccept?'✅ Confirmar aceptación':'❌ Confirmar rechazo')+'</button>'+
      '<button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>'+
    '</div>'
  );

  get('confirmDecisionBtn').addEventListener('click',function(){
    var notes=get('decisionNotes').value.trim();
    if(!isAccept && !notes){ showToast('Debes indicar el motivo del rechazo','error'); return; }
    var checklist={};
    document.querySelectorAll('.checklist-item').forEach(function(cb){ checklist[cb.dataset.item]=cb.checked; });
    var btn=get('confirmDecisionBtn'); btn.disabled=true; btn.textContent='Guardando…';
    api('/articles/'+articleId+'/decision',{method:'PUT',body:JSON.stringify({decision,notes,checklist})})
      .then(function(){
        showToast(isAccept?'Artículo aceptado. Ahora puedes asignar revisores.':'Artículo rechazado. El autor será notificado.',(isAccept?'success':'info'));
        closeModal(); loadEditorArticles(isAccept?'accepted':'rejected');
        // Cambiar tab automáticamente
        document.querySelectorAll('.etab').forEach(function(t){ t.classList.remove('active'); });
        var target=document.querySelector('.etab[data-etab="'+(isAccept?'accepted':'rejected')+'"]');
        if(target) target.classList.add('active');
      })
      .catch(function(e){ showToast(e.message,'error'); })
      .finally(function(){ btn.disabled=false; btn.textContent=isAccept?'✅ Confirmar aceptación':'❌ Confirmar rechazo'; });
  });
}

function assignReviewers(articleId){
  api('/users/reviewers').then(function(reviewers){
    var rows=reviewers.map(function(r){
      return '<label style="display:flex;align-items:center;gap:.75rem;padding:.65rem;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius-sm);margin-bottom:.5rem;cursor:pointer">'+
        '<input type="checkbox" name="rev" value="'+r.id+'" style="width:auto;accent-color:var(--accent)">'+
        '<span><span style="font-weight:500;color:var(--text-1)">'+esc(r.name)+'</span>'+
        '<span style="font-size:.75rem;color:var(--text-3);display:block">'+esc(r.email)+'</span></span></label>';
    }).join('');
    openModal('Asignar revisores',
      '<p style="color:var(--text-3);font-size:.85rem;margin-bottom:1.25rem">Selecciona 2 o 3 revisores.</p>'+
      rows+
      '<div class="btn-group" style="margin-top:1.25rem">'+
        '<button type="button" id="doAssignBtn" class="btn btn-primary">✅ Asignar y enviar a revisión</button>'+
        '<button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>'+
      '</div>'
    );
    get('doAssignBtn').addEventListener('click',function(){
      var sel=Array.from(document.querySelectorAll('input[name="rev"]:checked')).map(function(c){return c.value;});
      if(sel.length<2||sel.length>3){ showToast('Selecciona 2 o 3 revisores','error'); return; }
      api('/articles/'+articleId+'/assign',{method:'PUT',body:JSON.stringify({reviewerIds:sel})})
        .then(function(){
          showToast('Revisores asignados. Artículo en revisión.','success'); closeModal();
          document.querySelectorAll('.etab').forEach(function(t){ t.classList.remove('active'); });
          var target=document.querySelector('.etab[data-etab="inreview"]');
          if(target){ target.classList.add('active'); loadEditorArticles('inreview'); }
        })
        .catch(function(e){ showToast(e.message,'error'); });
    });
  }).catch(function(e){ showToast(e.message,'error'); });
}

function viewReviews(articleId,isEditor){
  api('/reviews/'+articleId).then(function(reviews){
    if(!reviews.length){ showToast('Sin revisiones aún','info'); return; }
    openModal('Revisiones ('+reviews.length+')',
      reviews.map(function(r,i){
        return '<div class="review-card">'+
          '<div class="review-card-header">'+
            '<div><div class="review-card-name">Revisor '+(i+1)+(isEditor?' — '+esc(r.reviewerName):'')+'</div>'+
            '<div class="review-card-date">'+new Date(r.submittedAt).toLocaleString('es-ES')+'</div></div>'+
            '<div style="text-align:center;background:var(--bg-hover);padding:.5rem 1rem;border-radius:var(--radius-sm);border:1px solid var(--border)">'+
              '<div style="font-family:var(--font-serif);font-size:1.6rem;color:var(--accent)">'+computeScore(r.scores)+'</div>'+
              '<div style="font-size:.7rem;color:var(--text-3)">/ 5.00</div>'+
            '</div>'+
          '</div>'+
          '<div class="score-grid">'+
            RUBRIC.criteria.map(function(c){
              return '<div class="score-cell"><div class="score-cell-label">'+c.name+'</div>'+
                '<div class="score-cell-value">'+((r.scores&&r.scores[c.id])||'—')+'<span style="font-size:.7rem;color:var(--text-3)">/5</span></div></div>';
            }).join('')+
          '</div>'+
          '<div class="comment-block"><div class="comment-block-title">💬 Comentarios para el autor</div>'+
            '<p style="font-size:.875rem;color:var(--text-2);line-height:1.65">'+esc(r.comments)+'</p></div>'+
          (isEditor&&r.editorComment?
            '<div class="comment-block confidential"><div class="comment-block-title">🔒 Confidencial — editor</div>'+
            '<p style="font-size:.875rem;color:var(--text-2);line-height:1.65">'+esc(r.editorComment)+'</p></div>':'')+
        '</div>';
      }).join('')
    );
  }).catch(function(e){ showToast(e.message,'error'); });
}

// ══════════════════════════════════════════════════════════════
// REVIEWER
// ══════════════════════════════════════════════════════════════
function renderReviewer(){
  get('appContent').innerHTML=
    '<div class="card">'+
      '<div class="card-title" style="justify-content:space-between">📚 Artículos asignados'+
        '<button class="btn btn-secondary btn-sm" onclick="loadReviewerArticles()">↻ Actualizar</button>'+
      '</div>'+
      '<div id="reviewerArticles"></div>'+
    '</div>';
  loadReviewerArticles();
}

function loadReviewerArticles(){
  setLoading('reviewerArticles');
  api('/articles').then(function(arts){
    if(!arts.length){ setEmpty('reviewerArticles','📭','Sin artículos asignados','El editor te asignará artículos cuando los acepte.'); return Promise.resolve(null); }
    return Promise.all(arts.map(function(a){
      return api('/reviews/'+a.id)
        .then(function(rs){ return Object.assign({},a,{_done:rs.length>0}); })
        .catch(function(){ return Object.assign({},a,{_done:false}); });
    }));
  }).then(function(augmented){
    if(!augmented) return;
    var c=get('reviewerArticles');
    c.innerHTML=augmented.map(function(a){
      return '<div class="article-item">'+
        '<div class="article-item-title">'+esc(a.title)+'</div>'+
        '<div class="article-item-meta">'+
          '<span>👤 '+esc(a.authorName||'')+'</span>'+
          '<span>📂 '+esc(a.area)+'</span>'+
          '<span>🗓 '+new Date(a.createdAt).toLocaleDateString('es-ES')+'</span>'+
          (a.hasPdf?'<span style="color:var(--accent)">📄 PDF</span>':'')+
        '</div>'+
        (a.abstract?'<p style="font-size:.82rem;color:var(--text-3);margin:.5rem 0 0">'+esc(a.abstract)+'</p>':'')+
        '<div class="article-item-footer" style="margin-top:.85rem">'+
          '<div class="btn-group" data-id="'+a.id+'">'+
            (a.hasPdf?'<button class="btn btn-secondary btn-sm pdf-btn">📄 Ver PDF</button>':'')+
            (!a._done
              ?'<button class="btn btn-primary btn-sm review-btn">✍️ Realizar revisión</button>'
              :'<button class="btn btn-secondary btn-sm my-review-btn">👁 Ver mi revisión</button>')+
          '</div>'+
          '<span class="badge '+(a._done?'badge-reviewed':'badge-in_review')+'">'+(a._done?'✅ Revisado':'⏳ Pendiente')+'</span>'+
        '</div>'+
      '</div>';
    }).join('');

    c.addEventListener('click',function(e){
      var btn=e.target.closest('button'); if(!btn)return;
      var g=btn.closest('[data-id]'); if(!g)return;
      var id=g.dataset.id;
      if(btn.classList.contains('pdf-btn'))      viewPdf(id);
      if(btn.classList.contains('review-btn'))   { var title=btn.closest('.article-item').querySelector('.article-item-title').textContent; openReviewModal(id,title); }
      if(btn.classList.contains('my-review-btn')) viewMyReview(id);
    });
  }).catch(function(e){ get('reviewerArticles').innerHTML='<div class="alert alert-error">'+esc(e.message)+'</div>'; });
}

function openReviewModal(articleId,articleTitle){
  openModal('Revisar artículo',
    '<p style="color:var(--text-3);font-size:.85rem;margin-bottom:1.5rem">Evaluando: <strong style="color:var(--text-1)">'+esc(articleTitle)+'</strong></p>'+
    renderRubricForm()+
    '<div class="score-display hidden" id="liveScore"><div class="score-value" id="liveScoreVal">—</div><div class="score-label">Calificación ponderada / 5.00</div></div>'+
    '<div class="form-group" style="margin-top:1.5rem">'+
      '<label>💬 Comentarios para el autor <span style="color:var(--red)">*</span></label>'+
      '<textarea id="rc_author" rows="5" placeholder="Retroalimentación constructiva (mínimo 100 caracteres)…"></textarea>'+
      '<span id="charCount" style="font-size:.72rem;color:var(--text-3)">0 / mín. 100</span>'+
    '</div>'+
    '<div class="form-group">'+
      '<label>🔒 Comentarios confidenciales para el editor <span style="font-size:.72rem;color:var(--text-3);font-weight:400">(opcional)</span></label>'+
      '<textarea id="rc_editor" rows="3" placeholder="Recomendación: aceptar / rechazar / revisar…"></textarea>'+
    '</div>'+
    '<div class="btn-group" style="margin-top:1.5rem">'+
      '<button type="button" id="submitReviewBtn" class="btn btn-success">📨 Enviar revisión</button>'+
      '<button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>'+
    '</div>'
  );

  document.querySelectorAll('.rating-opt').forEach(function(inp){
    inp.addEventListener('change',function(){
      var scores={},all=true;
      RUBRIC.criteria.forEach(function(c){
        var s=document.querySelector('.rating-opt[name="'+c.id+'"]:checked');
        if(s) scores[c.id]=parseInt(s.value); else all=false;
      });
      if(all){ get('liveScore').classList.remove('hidden'); get('liveScoreVal').textContent=computeScore(scores); }
    });
  });

  get('rc_author').addEventListener('input',function(){
    var n=this.value.length,el=get('charCount');
    el.textContent=n+' / mín. 100'; el.style.color=n>=100?'var(--green)':'var(--text-3)';
  });

  get('submitReviewBtn').addEventListener('click',function(){
    var scores={},allFilled=true;
    RUBRIC.criteria.forEach(function(c){
      var s=document.querySelector('.rating-opt[name="'+c.id+'"]:checked');
      if(s) scores[c.id]=parseInt(s.value); else allFilled=false;
    });
    if(!allFilled){ showToast('Evalúa todos los criterios','error'); return; }
    var comments=get('rc_author').value.trim();
    if(comments.length<100){ showToast('Los comentarios deben tener al menos 100 caracteres','error'); return; }
    var editorComment=get('rc_editor').value.trim();
    var btn=get('submitReviewBtn'); btn.disabled=true; btn.textContent='Enviando…';
    api('/reviews',{method:'POST',body:JSON.stringify({articleId,scores,comments,editorComment:editorComment||null})})
      .then(function(){ showToast('Revisión enviada correctamente','success'); closeModal(); loadReviewerArticles(); })
      .catch(function(e){ showToast(e.message,'error'); btn.disabled=false; btn.textContent='📨 Enviar revisión'; });
  });
}

function viewMyReview(articleId){
  api('/reviews/'+articleId).then(function(reviews){
    var mine=reviews[0]; if(!mine){ showToast('No se encontró tu revisión','error'); return; }
    openModal('Mi revisión',
      '<div class="score-display"><div class="score-value">'+computeScore(mine.scores)+'</div><div class="score-label">Calificación ponderada / 5.00</div></div>'+
      '<div class="score-grid" style="margin-bottom:1.25rem">'+
        RUBRIC.criteria.map(function(c){
          return '<div class="score-cell"><div class="score-cell-label">'+c.name+'</div>'+
            '<div class="score-cell-value">'+((mine.scores&&mine.scores[c.id])||'—')+'<span style="font-size:.7rem;color:var(--text-3)">/5</span></div></div>';
        }).join('')+
      '</div>'+
      '<div class="comment-block"><div class="comment-block-title">💬 Tus comentarios para el autor</div>'+
        '<p style="font-size:.875rem;color:var(--text-2);line-height:1.65">'+esc(mine.comments)+'</p></div>'+
      (mine.editorComment?'<div class="comment-block confidential"><div class="comment-block-title">🔒 Confidencial para el editor</div><p style="font-size:.875rem;color:var(--text-2);line-height:1.65">'+esc(mine.editorComment)+'</p></div>':'')+
      '<p style="font-size:.75rem;color:var(--text-3);margin-top:1rem">Enviado: '+new Date(mine.submittedAt).toLocaleString('es-ES')+'</p>'
    );
  }).catch(function(e){ showToast(e.message,'error'); });
}

// ── PDF viewer ────────────────────────────────────────────────
function viewPdf(articleId){
  openModal('Cargando PDF…','<div class="loading-state"><div class="spinner"></div><span>Descargando PDF…</span></div>');
  api('/articles/'+articleId+'/pdf').then(function(data){
    var binary=atob(data.pdfData), bytes=new Uint8Array(binary.length);
    for(var i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
    var url=URL.createObjectURL(new Blob([bytes],{type:'application/pdf'}));
    get('modalTitle').textContent='📄 '+(data.fileName||'documento.pdf');
    get('modalBody').innerHTML=
      '<div style="margin-bottom:.75rem;display:flex;gap:.5rem;flex-wrap:wrap">'+
        '<a href="'+url+'" target="_blank" class="btn btn-primary btn-sm">↗ Abrir en nueva pestaña</a>'+
        '<a href="'+url+'" download="'+esc(data.fileName||'documento.pdf')+'" class="btn btn-secondary btn-sm">⬇ Descargar</a>'+
      '</div>'+
      '<iframe src="'+url+'" style="width:100%;height:70vh;border:none;border-radius:var(--radius-sm);background:#fff"></iframe>';
  }).catch(function(e){ get('modalTitle').textContent='Error'; get('modalBody').innerHTML='<div class="alert alert-error">'+esc(e.message)+'</div>'; });
}
